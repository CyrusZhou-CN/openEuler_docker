***********
Version 1.0
***********

Release date: 2016-09-29

The first major release of pgAdmin 4.   With a more modern look and feel, this
release includes the following features;

* Multiplatform
* Designed for multiple PostgreSQL versions and derivatives
* Extensive documentation
* Multiple deployment models
* Tools
* Routine maintenance
* Create, view and edit all common PostgreSQL objects
* Multibyte support




