COMMENT ON CAST (money AS bigint)
    IS 'Cast from money to bigint';
