-- Extension: citext

-- DROP EXTENSION citext;

CREATE EXTENSION IF NOT EXISTS citext
    SCHEMA public
    VERSION "1.0";
