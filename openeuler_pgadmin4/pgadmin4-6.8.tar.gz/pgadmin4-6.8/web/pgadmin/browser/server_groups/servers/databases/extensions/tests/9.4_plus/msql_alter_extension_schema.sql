ALTER EXTENSION sslinfo
    SET SCHEMA public;
