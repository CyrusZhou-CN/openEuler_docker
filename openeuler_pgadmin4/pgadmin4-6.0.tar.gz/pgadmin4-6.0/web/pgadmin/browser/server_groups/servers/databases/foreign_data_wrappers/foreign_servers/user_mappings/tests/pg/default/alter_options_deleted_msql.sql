ALTER USER MAPPING FOR postgres SERVER test_fs_for_user_mapping
    OPTIONS (DROP "user", DROP password);
