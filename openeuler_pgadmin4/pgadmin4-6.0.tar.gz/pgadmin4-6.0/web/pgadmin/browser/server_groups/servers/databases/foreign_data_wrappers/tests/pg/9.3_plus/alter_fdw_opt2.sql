-- Foreign Data Wrapper: Fdw1_$%{}[]()&*^!@"'`\/#

-- DROP FOREIGN DATA WRAPPER IF EXISTS "Fdw1_$%{}[]()&*^!@""'`\/#"

CREATE FOREIGN DATA WRAPPER "Fdw1_$%{}[]()&*^!@""'`\/#"
    OPTIONS (opt1 'val1', opt2 'val2');

ALTER FOREIGN DATA WRAPPER "Fdw1_$%{}[]()&*^!@""'`\/#"
    OWNER TO <OWNER>;

COMMENT ON FOREIGN DATA WRAPPER "Fdw1_$%{}[]()&*^!@""'`\/#"
    IS 'a comment';
