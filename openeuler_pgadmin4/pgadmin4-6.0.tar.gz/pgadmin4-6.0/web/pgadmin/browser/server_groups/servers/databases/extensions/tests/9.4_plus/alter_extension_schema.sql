-- Extension: sslinfo

-- DROP EXTENSION sslinfo;

CREATE EXTENSION IF NOT EXISTS sslinfo
    SCHEMA public
    VERSION "1.0";
