SELECT db.datname as name FROM pg_catalog.pg_database as db WHERE db.oid = {{did}}
