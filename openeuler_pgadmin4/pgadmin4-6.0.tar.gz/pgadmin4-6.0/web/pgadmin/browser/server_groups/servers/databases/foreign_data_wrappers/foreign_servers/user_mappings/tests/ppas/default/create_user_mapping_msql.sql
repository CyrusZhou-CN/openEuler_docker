CREATE USER MAPPING FOR enterprisedb SERVER test_fs_for_user_mapping
    OPTIONS ("user" 'test_user', password 'secret');
